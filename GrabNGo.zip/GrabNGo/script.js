//``````````````food.js````````````//
//select all the e that have class .food-image-food and loop for each one
document.querySelectorAll(".food-image-food").forEach((card) => {
  // DOM (Document Object Model) method in JavaScript used to select multiple elements from the web page.

  // When the mouse hovers over the image, scale it up slightly and add a shadow
  card.onmouseover = () => {
    card.style.transform = "scale(1.05)";
    card.style.boxShadow = "0 8px 16px rgba(0,0,0,0.2)";
  };
  card.onmouseout = () => {
    card.style.transform = "scale(1)";
    card.style.boxShadow = "0 4px 8px rgba(0,0,0,0.1)";
  };
  card.onclick = () => {
    alert(`You selected ${card.nextElementSibling.textContent}`); //${}  template literal expression
  };
});
//``````````````groceries.js````````````//
document.querySelectorAll(".groceries-img").forEach((card) => {
  card.onmouseover = () => {
    card.style.transform = "scale(1.05)";
    card.style.boxShadow = "0 8px 16px rgba(0,0,0,0.2)";
  };
  card.onmouseout = () => {
    card.style.transform = "scale(1)";
    card.style.boxShadow = "0 4px 8px rgba(0,0,0,0.1)";
  };
  card.onclick = () => {
    alert(`You selected ${card.nextElementSibling.textContent}`); //${}  template literal expression
  };
});
//``````````````sign.js````````````//

const signInButton = document.querySelector(".Sign-in-sign-in"); //Select Sign button
const usernameInput = document.getElementById("username-sign-in"); // username input
const passwordInput = document.getElementById("Password-sign-in"); // password input

//``````````````users````````````//
//array of objects.
//object is a data structure that stores data in key–value pairs. It's used to represent and group related data together.
const users = [
  { username: "mohammed", password: "mohammed123" }, //key = username , value = mohammed
  { username: "ahmed", password: "ahmed123" },
  { username: "osama", password: "osama123" },
  { username: "rana", password: "rana123" },
];

signInButton.addEventListener("click", () => {
  const enteredUsername = usernameInput.value;
  const enteredPassword = passwordInput.value;

  const validUser = users.find(
    //find is a loop
    // Returns the value of the first element in the array where predicate is true, and undefined otherwise.
    (user) =>
      user.username === enteredUsername && user.password === enteredPassword
  );
  console.log(validUser);

  if (validUser) {
    alert(`Login successful. Welcome back \n \t ${enteredUsername}\t`);
  } else {
    alert(" Invalid username or password. Try again.");
  }
  usernameInput.value = "";
  passwordInput.value = "";
});
